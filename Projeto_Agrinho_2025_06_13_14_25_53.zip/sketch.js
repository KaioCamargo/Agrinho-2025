// =========================================================
// Variáveis Globais do Jogo
// =========================================================
let gameState = 'inicio'; // Estado inicial agora é 'inicio'

// Personagem Principal (o pescador)
let playerX;
let playerY;
let playerSpeed = 3;
let playerHasHat = false; // AGORA: Controla se o jogador tem o chapéu APENAS na festa

// NPC
let npcX;
let npcY;
let npcSpeed = 2;
let showNpcDialog = false;
let npcDialogStep = 0;
const npcDialogs = [
    "Ei, amigo! Que bom te ver por aqui!",
    "Tá rolando a maior festa junina lá no sítio!",
    "Que tal a gente dar um pulo por lá? Vai ser demais!",
    "Vamos lá!"
];

// Barco e Anzol (do jogo de pescaria)
let pescadorX;
let pescadorY;
let barcoY;
let anzolY;
let isLancando = false;
let peixePego = null;
let peixes = [];
let pontuacaoPescaria = 0;

// Variáveis para as mensagens de festa junina (do jogo de pescaria)
let ultimoItemGanhoPescaria = -1;
const itensJuninosPescaria = [
    { pontos: 5, mensagem: "Parabéns! Você ganhou uma Pipoca quentinha!" },
    { pontos: 15, mensagem: "Ótimo! Você fisgou um Pé de Moleque!" },
    { pontos: 30, mensagem: "Incrível! Olha a Quadrilha! É um Balão!" },
    { pontos: 50, "mensagem": "Mandou bem! Você ganhou um Bolo de Fubá!" },
    { pontos: 80, mensagem: "Que festa! Conseguiu um Milho Cozido!" }
];
let mensagemItemAtualPescaria = "";
let tempoMensagemPescaria = 0;

// BLIP da pescaria
let blipX;
let blipY;
let blipRadius = 10;
let blipPulse = 0; // Para animação do BLIP

// =========================================================
// NOVAS VARIÁVEIS PARA O JOGO DE TIRO AO ALVO
// =========================================================
let blipTiroX;
let blipTiroY;
let showTiroDialog = false;
let pontuacaoTiro = 0;
let alvos = [];
let maxAlvosAtivos = 3; // Número máximo de alvos na tela ao mesmo tempo
let tempoParaNovoAlvo = 0;
let intervaloGeracaoAlvo = 90; // Gerar um novo alvo a cada 1.5 segundos (90 frames)
let tempoAlvoVisivel = 120; // Alvo visível por 2 segundos (120 frames) antes de sumir
let jogoTiroAtivo = false;
let tempoInicioJogoTiro;
let duracaoJogoTiro = 30; // Duração do jogo em segundos (ajustado para 30s)
let tempoRestanteTiro = duracaoJogoTiro;

// Prêmio final
let premioFinalTiro = "";

// NOVAS VARIÁVEIS PARA A ARMA E MIRA
let armaX, armaY; // Posição da arma (fixa na parte inferior)
let armaBaseX, armaBaseY; // Nova variável para a base da arma
let miraSize = 30; // Tamanho da mira
let miraCorpoOffset = 5; // Espessura do corpo da mira
let miraCor = [255, 0, 0]; // Cor vermelha para a mira

// Variáveis para o tranco da arma
let trancoOffset = 0; // Deslocamento Y para o tranco
let trancoAnimando = false;
let trancoTimer = 0;

// =========================================================
// Variáveis para a transição do pôr do sol e carro
// =========================================================
let sunY;
let skyColorTransition;
let carX;

// Array para armazenar as posições das estrelas
let stars = [];

// Variáveis para as músicas de fundo
let musicaCaminho; // Música para o caminho
let musicaFesta;   // Música para a festa junina

// Botão de Sair da Pescaria e Tiro
let exitButtonX;
let exitButtonY;
let exitButtonWidth = 80;
let exitButtonHeight = 30;

// Variáveis para as imagens
let fogueiraImg; // Permanece para o desenho da fogueira na festa
let chapeuImg; // Permanece para o desenho do chapéu do stickman padrão

// Variáveis para o botão de início (novo)
let startButtonX;
let startButtonY;
let startButtonWidth = 200;
let startButtonHeight = 50;
let startButtonPulse = 0; // Para animação do botão

// =========================================================
// Pré-carregamento (roda antes do setup)
// =========================================================
function preload() {
    // Carrega a música do caminho
    musicaCaminho = loadSound('musica_caminho.mp3');
    // Carrega a música da festa
    musicaFesta = loadSound('musica_festa.mp3');
    // Carrega as imagens
    fogueiraImg = loadImage('fogueira.png');
    chapeuImg = loadImage('chapeu.png');
}


// =========================================================
// Setup
// =========================================================
function setup() {
    createCanvas(600, 400);

    // Configura o volume das músicas (opcional, mas recomendado)
    musicaCaminho.setVolume(0.3); // Volume mais baixo para a música de transição
    musicaFesta.setVolume(0.5);   // Volume da música da festa

    // Posições iniciais na cidade (serão redefinidas ao iniciar o jogo)
    playerX = width / 4;
    playerY = height - 50;
    npcX = width + 50; // NPC começa fora da tela
    npcY = height - 50;

    // Configurações do jogo de pescaria (apenas para inicializar)
    pescadorX = width / 2;
    barcoY = height / 4 + 20;
    pescadorY = barcoY - 25;
    anzolY = pescadorY;

    // Posição da barraca de pescaria e do BLIP na festa
    // blipX centralizado na barraca de pescaria (width * 0.65 é o início da barraca, 100 é a largura dela)
    blipX = (width * 0.65) + (100 / 2);
    blipY = height - 50; // Chão da festa (ajuste para a altura do player)

    // Posição do BLIP da barraca de tiro (width * 0.2 é o início da barraca de tiro)
    blipTiroX = (width * 0.2) + (100 / 2);
    blipTiroY = height - 50;

    // Inicializa os peixes para o jogo de pescaria
    for (let i = 0; i < 5; i++) {
        peixes.push(criarPeixe());
    }

    // Inicializa variáveis da transição
    sunY = height / 4; // Sol no alto
    skyColorTransition = color(135, 206, 235); // Céu azul claro
    carX = -100; // Carro começa fora da tela

    // Inicializa as estrelas (posições fixas)
    for (let i = 0; i < 50; i++) {
        stars.push({
            x: random(width),
            y: random(height / 2), // Apenas na parte superior do céu
            size: random(1, 3)
        });
    }

    // Posição do botão de saída da pescaria e tiro
    exitButtonX = width / 2 - exitButtonWidth / 2; // Centralizado no topo
    exitButtonY = 10; // 10 pixels de margem do topo

    // Posição do botão de início
    startButtonX = width / 2 - startButtonWidth / 2;
    startButtonY = height / 2 + 50;

    // Posição da base da arma (fixa na parte inferior central da tela)
    armaBaseX = width / 2;
    armaBaseY = height - 35; // Um pouco acima do chão
}

// =========================================================
// Loop Principal - draw()
// =========================================================
function draw() {
    // Limpa a tela a cada frame
    background(220);

    switch (gameState) {
        case 'inicio':
            drawInicio();
            break;
        case 'cidade':
            drawCidade();
            updateCidade();
            break;
        case 'caminho_festa':
            drawCaminhoFesta();
            updateCaminhoFesta();
            break;
        case 'festa_junina':
            drawFestaJunina();
            updateFestaJunina();
            break;
        case 'pescaria_dialogo':
            drawFestaJunina(); // Garante que o fundo da festa seja desenhado
            drawPescariaDialog();
            break;
        case 'pescaria_jogo':
            drawPescariaJogo();
            updatePescariaJogo();
            break;
        case 'tiro_dialogo': // Novo estado
            drawFestaJunina();
            drawTiroDialog();
            break;
        case 'tiro_jogo': // Novo estado
            drawTiroJogo();
            updateTiroJogo();
            break;
        case 'tiro_fim_jogo': // Novo estado para o fim do jogo de tiro
            drawFestaJunina(); // Desenha o fundo da festa
            drawTiroFimJogo();
            break;
    }

    // Código para os BLIPs (sempre visível no estado de festa e diálogo)
    if (gameState === 'festa_junina' || gameState === 'pescaria_dialogo') {
        drawBlip(blipX, blipY); // Blip da Pescaria
    }
    if (gameState === 'festa_junina' || gameState === 'tiro_dialogo') {
        drawBlip(blipTiroX, blipTiroY); // Blip do Tiro
    }

    // Esconde o cursor do mouse e desenha a mira se estiver no jogo de tiro
    if (gameState === 'tiro_jogo') {
        noCursor(); // Esconde o cursor padrão do mouse
        drawMira(mouseX, mouseY); // Desenha a mira na posição do mouse
    } else {
        cursor(); // Mostra o cursor padrão do mouse em outros estados
    }
}

// =========================================================
// Funções de Desenho para cada Estado
// =========================================================

function drawInicio() {
    // Fundo gradiente
    for (let y = 0; y < height; y++) {
        let inter = map(y, 0, height, 0, 1);
        let c = lerpColor(color(135, 206, 250), color(0, 50, 150), inter); // De azul claro para azul escuro
        stroke(c);
        line(0, y, width, y);
    }

    // Chão mais escuro (opcional, pode remover se não quiser)
    fill(40, 40, 40);
    rect(0, height - 70, width, 70);

    // Título principal
    fill(255, 255, 0); // Amarelo vibrante
    noStroke(); // Garante que o texto não terá contorno
    textSize(48);
    textAlign(CENTER, CENTER);
    text("Festa Junina Aventura", width / 2, height / 2 - 80);

    // Animação de pulso para o botão
    startButtonPulse = (sin(frameCount * 0.05) * 5) + 10; // Pulsa entre 5 e 15 pixels

    // Desenha o botão de início
    fill(255, 165, 0, 200 + startButtonPulse * 5); // Laranja com pulso de opacidade
    stroke(255, 200, 0);
    strokeWeight(3);
    rect(startButtonX - startButtonPulse / 2, startButtonY - startButtonPulse / 2,
         startButtonWidth + startButtonPulse, startButtonHeight + startButtonPulse, 15);

    fill(255); // Texto branco
    noStroke(); // Garante que o texto não terá contorno
    textSize(24);
    // ADICIONADO O AJUSTE DE +30 PIXELS NA POSIÇÃO Y para uma centralização visual melhor
    text("Clique para Começar", width / 2, height / 2 + 50 + 30); // Centralizado no botão

    textAlign(LEFT, BASELINE); // Resetar alinhamento para outros estados
    noStroke(); // Garante que não haja stroke residual
}

function drawCidade() {
    // Céu
    background(100, 150, 200); // Céu azul claro
    fill(255); // Nuvens brancas
    noStroke(); // Sem contorno para as nuvens
    drawCloud(50, 50, 1);
    drawCloud(250, 80, 0.8);
    drawCloud(450, 60, 1.1);

    // Estrada (asfalto)
    fill(80, 80, 80);
    rect(0, height - 70, width, 70);

    // Faixa da estrada
    fill(255, 255, 0); // Amarelo
    rect(0, height - 45, width, 5);

    // Calçadas
    fill(150, 150, 150);
    rect(0, height - 90, width, 20); // Calçada superior (onde os prédios ficam)
    rect(0, height - 20, width, 20); // Calçada inferior

    // Prédios simples e variados
    fill(120);
    rect(50, height - 190, 80, 100); // Prédio 1
    rect(180, height - 240, 100, 150); // Prédio 2
    rect(350, height - 160, 60, 70); // Prédio 3
    fill(100);
    rect(450, height - 220, 90, 130); // Prédio 4

    // Janelas nos prédios
    fill(170, 200, 255); // Azul claro para janelas
    rect(60, height - 180, 15, 20); rect(90, height - 180, 15, 20);
    rect(190, height - 230, 20, 25); rect(230, height - 230, 20, 25);
    rect(360, height - 150, 10, 15); rect(380, height - 150, 10, 15);
    rect(460, height - 210, 20, 20); rect(490, height - 210, 20, 20);

    // Paisagismo (Árvores e Arbustos)
    // Árvore 1
    fill(139, 69, 19); // Tronco
    rect(100, height - 140, 15, 50);
    fill(34, 139, 34); // Folhas
    ellipse(107, height - 170, 60, 60);

    // Árvore 2
    fill(139, 69, 19); // Tronco
    rect(300, height - 120, 15, 50);
    fill(34, 139, 34); // Folhas
    ellipse(307, height - 150, 60, 60);

    // Arbustos
    fill(60, 179, 113);
    ellipse(20, height - 80, 40, 25);
    ellipse(320, height - 85, 35, 20);
    ellipse(580, height - 80, 40, 25);


    // Placa "Sítio do Vovô"
    drawRoadSign(width - 150, height - 160, "Sítio do Vovô", "direita");

    // Personagem principal (sem chapéu na cidade)
    drawStickman(playerX, playerY, 0, false);

    // NPC (sem chapéu na cidade)
    drawStickman(npcX, npcY, 0, false);

    // Diálogo do NPC
    if (showNpcDialog) {
        drawDialogBox(npcDialogs[npcDialogStep]);
    }
}

function drawCaminhoFesta() {
    // --- Desenha o CÉU ---
    background(skyColorTransition);

    // --- Desenha o SOL ---
    fill(255, 200, 0); // Laranja avermelhado
    noStroke(); // Sol sem contorno
    ellipse(width / 2, sunY, 80, 80); // Sol

    // --- Desenha o CHÃO (que agora vai cobrir o sol) ---
    fill(80, 80, 80); // Cor da estrada/chão
    noStroke(); // Chão sem contorno
    rect(0, height - 70, width, 70); // Chão de verdade

    // Desenha o carro
    drawCar(carX, height - 100);

    fill(0);
    noStroke(); // Garante que o texto não terá contorno
    textSize(20);
    textAlign(CENTER, CENTER);
    text("Indo para o Sítio...", width / 2, 50); // Texto alterado
    textAlign(LEFT, BASELINE);
}

function drawFestaJunina() {
    background(50, 50, 80); // Céu noturno
    drawStars(); // Desenha as estrelas
    fill(100, 100, 100); // Chão de terra
    noStroke(); // Chão sem contorno
    rect(0, height - 70, width, 70);

    // Fogueira Centralizada (agora com imagem)
    let fogueiraX = width / 2;
    let fogueiraBaseY = height - 70; // Altura do chão
    if (fogueiraImg) { // Só desenha se a imagem foi carregada
        imageMode(CENTER);
        // Diminuído o tamanho para 0.15 da largura original
        // Ajustada a posição Y para que a base da fogueira fique no chão
        image(fogueiraImg, fogueiraX, fogueiraBaseY - fogueiraImg.height * 0.15 / 2 + 5, fogueiraImg.width * 0.15, fogueiraImg.height * 0.15);
        imageMode(CORNER);
    } else {
        // Se a imagem não carregar, desenha a fogueira antiga como fallback
        noStroke();
        fill(255, 0, 0, 150); // Vermelho com transparência
        ellipse(fogueiraX, fogueiraBaseY - 35, 45, 45);
        fill(255, 100, 0, 200); // Laranja mais forte
        ellipse(fogueiraX + 5, fogueiraBaseY - 50, 35, 35);
        fill(255, 200, 0, 255); // Amarelo-laranja (mais opaco)
        ellipse(fogueiraX - 5, fogueiraBaseY - 65, 25, 25);
        fill(255, 150, 0, 50); // Brilho no chão
        ellipse(fogueiraX, fogueiraBaseY - 30, 80, 50);
    }


    // Barracas Típicas de Festa Junina
    // Barraca 1 (Esquerda - TIRO AO ALVO)
    drawFestaJuninaBarraca(width * 0.2, height - 70, color(200, 50, 50), "Tiro ao Alvo");

    // Barraca da Pescaria (Direita)
    drawFestaJuninaBarraca(width * 0.65, height - 70, color(50, 150, 200), "Pescaria");

    // Bandeirinhas (vindo da direita e cobrindo a tela inteira)
    drawBandeirinhas(50, 10); // Chamada para desenhar as bandeirinhas

    // Personagem principal na festa (desenhado por último para ficar na frente de tudo)
    // AGORA com playerHasHat
    drawStickman(playerX, playerY, 0, playerHasHat);
}

function drawPescariaDialog() {
    // Desenha a caixa de diálogo
    fill(255, 255, 200); // Fundo da caixa de diálogo
    stroke(0); // Bordas da caixa de diálogo
    strokeWeight(1); // Espessura da borda da caixa
    rect(width / 2 - 150, height / 2 - 50, 300, 100, 10);

    fill(0);
    noStroke(); // Garante que o texto NÃO terá contorno
    textSize(18);
    textAlign(CENTER, CENTER);
    text("Quer participar da pescaria?", width / 2, height / 2 - 10);
    textSize(16);
    text("[S] Sim   [N] Não", width / 2, height / 2 + 30);
    textAlign(LEFT, BASELINE); // Resetar alinhamento
}

function drawTiroDialog() { // Nova função de diálogo para o Tiro
    fill(255, 255, 200);
    stroke(0);
    strokeWeight(1);
    rect(width / 2 - 150, height / 2 - 50, 300, 100, 10);

    fill(0);
    noStroke();
    textSize(18);
    textAlign(CENTER, CENTER);
    text("Topa um desafio de pontaria?", width / 2, height / 2 - 10);
    textSize(16);
    text("[S] Sim   [N] Não", width / 2, height / 2 + 30);
    textAlign(LEFT, BASELINE);
}

function drawPescariaJogo() {
    // --- Cores do Céu, Nuvens e da Água ---
    let skyColor = color(135, 206, 235); // Azul claro para o céu
    let waterColor = color(0, 100, 150); // Azul mais escuro para a água
    let cloudColor = color(255); // Branco para as nuvens

    // Desenha o **CÉU**
    fill(skyColor);
    noStroke();
    rect(0, 0, width, barcoY + 35);

    // Desenha as **NUVENS**
    fill(cloudColor); // Garante que as nuvens são brancas
    noStroke(); // Garante que as nuvens não têm contorno
    drawCloud(50, 50, 1);
    drawCloud(200, 80, 0.75);
    drawCloud(350, 30, 1.2);
    drawCloud(500, 60, 0.9);

    // Desenha a **ÁGUA**
    fill(waterColor);
    rect(0, barcoY + 35, width, height - (barcoY + 35));

    // --- Desenha o Stickman Pescador ---
    stroke(0);
    strokeWeight(2);

    // Cabeça
    fill(255);
    ellipse(pescadorX, pescadorY - 20, 30, 30);

    // Corpo
    line(pescadorX, pescadorY - 5, pescadorX, pescadorY + 15);

    // Braços
    line(pescadorX - 15, pescadorY - 5, pescadorX + 15, pescadorY - 5); // ORIGINAL: braços na horizontal

    // Pernas
    line(pescadorX, pescadorY + 15, pescadorX - 10, pescadorY + 35);
    line(pescadorX, pescadorY + 15, pescadorX + 10, pescadorY + 35);

    // Vara de pesca
    stroke(139, 69, 19);
    strokeWeight(4);
    line(pescadorX + 15, pescadorY - 10, pescadorX + 45, pescadorY - 10); // Parte da vara na mão do pescador
    line(pescadorX + 45, pescadorY - 10, pescadorX + 45, anzolY); // Resto da vara (agora descendo)
    strokeWeight(1);

    // --- Desenha o Barco ---
    fill(139, 69, 19);
    noStroke();

    // Corpo do barco
    rect(pescadorX - 80, barcoY, 160, 40);

    // Pontas do barco
    arc(pescadorX - 80, barcoY + 20, 40, 40, HALF_PI, PI + HALF_PI);
    arc(pescadorX + 80, barcoY + 20, 40, 40, PI + HALF_PI, HALF_PI);

    // Linha d'água
    stroke(0, 150, 200);
    strokeWeight(3);
    line(0, barcoY + 35, width, barcoY + 35);
    noStroke();

    // --- Desenha a linha da vara e o anzol ---
    stroke(0);
    line(pescadorX + 45, anzolY, pescadorX + 45, pescadorY - 10); // A linha sai da ponta da vara
    fill(255, 0, 0);
    ellipse(pescadorX + 45, anzolY, 8, 8); // Anzol (agora no X da vara)

    // Desenha e move os peixes
    for (let i = 0; i < peixes.length; i++) {
        let peixe = peixes[i];

        // Desenha o peixe (só se não estiver pego)
        if (!peixe.pego) {
            fill(peixe.cor.r, peixe.cor.g, peixe.cor.b);
            noStroke();
            push(); // Salva o estado atual
            translate(peixe.x, peixe.y);
            if (peixe.velocidadeX < 0) { // Inverte o peixe se estiver indo para a esquerda
                scale(-1, 1);
            }
            // Corpo do peixe (oval)
            ellipse(0, 0, peixe.tamanho, peixe.tamanho * 0.6);
            // Cauda do peixe (triângulo)
            triangle(-peixe.tamanho / 2, 0, -peixe.tamanho * 0.8, -peixe.tamanho * 0.3, -peixe.tamanho * 0.8, peixe.tamanho * 0.3);
            pop(); // Restaura o estado anterior
        } else {
            // Se o peixe está pego, desenha ele no anzol
            fill(peixe.cor.r, peixe.cor.g, peixe.cor.b);
            noStroke();
            push();
            translate(pescadorX + 45, anzolY + peixe.tamanho / 2); // Posição do anzol
            if (peixe.velocidadeX < 0) { // Mantém a direção que ele tinha
                scale(-1, 1);
            }
            ellipse(0, 0, peixe.tamanho, peixe.tamanho * 0.6);
            triangle(-peixe.tamanho / 2, 0, -peixe.tamanho * 0.8, -peixe.tamanho * 0.3, -peixe.tamanho * 0.8, peixe.tamanho * 0.3);
            pop();
        }
    }

    // Exibir a pontuação
    fill(0); // Cor do texto da pontuação
    noStroke(); // Garante que o texto não terá contorno
    textSize(24);
    textAlign(RIGHT, TOP);
    text("Pontos: " + pontuacaoPescaria, width - 20, 50);
    textAlign(LEFT, BASELINE); // Resetar alinhamento


    // Mostra a mensagem de item de festa junina
    if (mensagemItemAtualPescaria !== "" && frameCount < tempoMensagemPescaria + 180) { // Mostra por 3 segundos (180 frames)
        fill(255, 165, 0); // Cor laranja para a mensagem
        noStroke(); // Garante que o texto não terá contorno
        textSize(28);
        textAlign(CENTER, CENTER);
        text(mensagemItemAtualPescaria, width / 2, height / 2);
        textAlign(LEFT, BASELINE); // Volta ao padrão
    }

    // Desenha o botão de SAIR (posição já definida no setup)
    fill(200, 50, 50); // Cor vermelha para o botão
    noStroke(); // Sem contorno para o botão para não interferir no texto
    rect(exitButtonX, exitButtonY, exitButtonWidth, exitButtonHeight, 5); // Botão retangular com bordas arredondadas

    fill(255); // Cor branca para o texto
    noStroke(); // Garante que o texto do botão não terá contorno
    textSize(16);
    textAlign(CENTER, CENTER);
    text("SAIR", exitButtonX + exitButtonWidth / 2, exitButtonY + exitButtonHeight / 2);
    textAlign(LEFT, BASELINE); // Resetar alinhamento
}

function drawTiroJogo() { // Nova função de desenho para o Tiro
    background(100, 150, 200); // Céu azul
    fill(80, 80, 80); // Chão/Área de tiro
    noStroke();
    rect(0, height - 70, width, 70);

    // Desenha os alvos
    for (let alvo of alvos) {
        if (alvo.ativo) {
            // Desenho do alvo com círculos: Branco, Preto, Vermelho
            noStroke(); // Garante que os círculos não terão contorno

            // Círculo externo (branco)
            fill(255);
            ellipse(alvo.x, alvo.y, alvo.size, alvo.size);

            // Círculo do meio (preto)
            fill(0);
            ellipse(alvo.x, alvo.y, alvo.size * 0.7, alvo.size * 0.7); // 70% do tamanho total

            // Círculo interno (vermelho) - o centro!
            fill(255, 0, 0); // Vermelho
            ellipse(alvo.x, alvo.y, alvo.size * 0.4, alvo.size * 0.4); // 40% do tamanho total
        }
    }

    // Exibir a pontuação
    fill(0);
    noStroke();
    textSize(24);
    // Pontuação agora no canto superior esquerdo
    textAlign(LEFT, TOP);
    text("PONTOS: " + pontuacaoTiro, 20, 20);
    // text(pontuacaoTiro, 20, 50); // Removido para uma linha

    // Exibir tempo restante
    fill(0);
    textSize(24);
    textAlign(RIGHT, TOP);
    text("TEMPO: " + ceil(tempoRestanteTiro), width - 20, 20); // Valor (ceil para arredondar para cima)
    textAlign(LEFT, BASELINE); // Resetar alinhamento

    // Desenha a arma na posição fixa, mas apontando para o mouse
    // Ajustado o 'armaBaseY' com 'trancoOffset' para animação de recuo
    drawArma(armaBaseX, armaBaseY + trancoOffset, mouseX, mouseY);

    // Desenha o botão de SAIR
    fill(200, 50, 50);
    noStroke();
    rect(exitButtonX, exitButtonY, exitButtonWidth, exitButtonHeight, 5);

    fill(255);
    noStroke();
    textSize(16);
    textAlign(CENTER, CENTER);
    text("SAIR", exitButtonX + exitButtonWidth / 2, exitButtonY + exitButtonHeight / 2);
    textAlign(LEFT, BASELINE);
}

function drawTiroFimJogo() { // Nova função para tela de fim de jogo de tiro
    // Fundo da festa já é desenhado antes de chamar esta função
    fill(0, 0, 0, 180); // Overlay escuro para destacar a mensagem
    rect(0, 0, width, height);

    fill(255); // Texto branco
    noStroke();
    textSize(36);
    textAlign(CENTER, CENTER);
    text("Fim de Jogo!", width / 2, height / 2 - 60);

    textSize(28);
    text("Sua Pontuação: " + pontuacaoTiro + " pontos", width / 2, height / 2);

    // Exibe o prêmio final!
    textSize(24);
    text("Você ganhou: " + premioFinalTiro + "!", width / 2, height / 2 + 40);


    textSize(20);
    text("Pressione [ESPACE] para voltar à festa", width / 2, height / 2 + 100);
    textAlign(LEFT, BASELINE);
}


function drawBlip(x, y) {
    blipPulse = (sin(frameCount * 0.1) * 5) + 15; // Faz o BLIP pulsar
    fill(0, 255, 0, 150); // Verde semi-transparente
    noStroke();
    ellipse(x, y, blipPulse * 2, blipPulse * 2);
    fill(0, 255, 0); // Verde sólido
    ellipse(x, y, blipRadius * 2, blipRadius * 2);
}

// =========================================================
// Funções de Atualização para cada Estado
// =========================================================

function updateCidade() {
    // Movimento do NPC
    if (npcX > playerX + 70) { // NPC se aproxima do jogador
        npcX -= npcSpeed;
    } else {
        showNpcDialog = true;
    }
}

function updateCaminhoFesta() {
    // Toca a música do caminho se ainda não estiver tocando
    if (!musicaCaminho.isPlaying()) {
        musicaCaminho.loop();
    }
    // Para a música da festa, se por acaso estiver tocando (não deveria, mas é uma garantia)
    if (musicaFesta.isPlaying()) {
        musicaFesta.stop();
    }

    // Movimento do carro (playerX e npcX seguem o carro)
    carX += playerSpeed;

    // Gradiente do céu (pôr do sol)
    let transitionProgress = map(carX, -100, width + 50, 0, 1);
    let r = lerp(135, 50, transitionProgress);
    let g = lerp(206, 50, transitionProgress);
    let b = lerp(235, 80, transitionProgress);
    skyColorTransition = color(r, g, b);

    sunY = map(carX, -100, width + 50, height / 4, height - 70 + 40 + 20);
    sunY = constrain(sunY, -50, height + 60);

    if (carX > width + 50) { // Quando o carro sair da tela
        gameState = 'festa_junina';
        playerX = width / 2; // Posição inicial do player na festa
        playerY = height - 50;
        npcX = width / 2 + 50; // Posição do NPC na festa (mesmo que não seja desenhado)
        npcY = height - 50;
        carX = -100;

        // Ativa o chapéu ao chegar na festa
        playerHasHat = true;

        // Para a música do caminho e toca a música da festa
        if (musicaCaminho.isPlaying()) {
            musicaCaminho.stop();
        }
        if (!musicaFesta.isPlaying()) {
            musicaFesta.loop();
        }
    }
}

function updateFestaJunina() {
    // Movimento do personagem principal (WASD ou Setas)
    if (keyIsDown(LEFT_ARROW) || keyIsDown(65)) { // Esquerda ou 'A'
        playerX -= playerSpeed;
    }
    if (keyIsDown(RIGHT_ARROW) || keyIsDown(68)) { // Direita ou 'D'
        playerX += playerSpeed;
    }
    if (keyIsDown(UP_ARROW) || keyIsDown(87)) { // Cima ou 'W'
        playerY -= playerSpeed;
    }
    if (keyIsDown(DOWN_ARROW) || keyIsDown(83)) { // Baixo ou 'S'
        playerY += playerSpeed;
    }

    // Limita o personagem à área do chão
    playerX = constrain(playerX, 0, width);
    playerY = constrain(playerY, height - 70, height - 20);

    // Detecção de proximidade com o BLIP da pescaria
    let dPesca = dist(playerX, playerY, blipX, blipY);
    // AUMENTEI o raio de detecção para facilitar
    if (dPesca < blipRadius + 30) {
        gameState = 'pescaria_dialogo';
    }

    // Detecção de proximidade com o BLIP do tiro
    let dTiro = dist(playerX, playerY, blipTiroX, blipTiroY);
    // AUMENTEI o raio de detecção para facilitar
    if (dTiro < blipRadius + 30) {
        gameState = 'tiro_dialogo';
    }
}

function updatePescariaJogo() {
    // Lógica do jogo de pescaria
    if (isLancando) {
        anzolY += 5; // Anzol desce
        // Verifica colisão com peixe apenas se o anzol estiver descendo
        for (let i = 0; i < peixes.length; i++) {
            let peixe = peixes[i];
            if (!peixe.pego && dist(pescadorX + 45, anzolY, peixe.x, peixe.y) < peixe.tamanho / 2 + 5) {
                peixePego = peixe;
                peixePego.pego = true;
                isLancando = false; // Parar de lançar, começar a puxar
                break;
            }
        }
        if (anzolY > height - 10) { // Se o anzol chegar no fundo sem pegar peixe
            isLancando = false;
        }
    } else { // Anzol subindo
        if (anzolY > pescadorY - 10) { // Puxa até a altura da vara
            anzolY -= 3;
            if (peixePego) {
                peixePego.y = anzolY + peixePego.tamanho / 2; // Move o peixe junto
            }
        } else {
            // Anzol chegou no pescador
            anzolY = pescadorY - 10;
            if (peixePego) {
                // Peixe foi pescado!
                pontuacaoPescaria += peixePego.pontos;

                // Verifica se ganhou um novo item de festa junina
                for (let i = itensJuninosPescaria.length - 1; i >= 0; i--) {
                    if (pontuacaoPescaria >= itensJuninosPescaria[i].pontos && i > ultimoItemGanhoPescaria) {
                        mensagemItemAtualPescaria = itensJuninosPescaria[i].mensagem;
                        tempoMensagemPescaria = frameCount; // Salva o frame atual para temporizar a mensagem
                        ultimoItemGanhoPescaria = i; // Atualiza o último item ganho
                        break;
                    }
                }

                // Remove o peixe pego e adiciona um novo
                const index = peixes.indexOf(peixePego);
                if (index > -1) {
                    peixes.splice(index, 1); // Remove o peixe pego
                }
                peixes.push(criarPeixe()); // Adiciona um novo peixe
                peixePego = null; // Limpa a referência
            }
        }
    }

    // Movimento dos peixes
    for (let i = 0; i < peixes.length; i++) {
        let peixe = peixes[i];
        if (!peixe.pego) { // Só move se não estiver pego
            peixe.x += peixe.velocidadeX;

            // Inverte a direção se atingir as bordas
            if (peixe.x < 0 - peixe.tamanho / 2 || peixe.x > width + peixe.tamanho / 2) {
                peixe.velocidadeX *= -1; // Inverte a direção
                // Ajusta a posição para não ficar preso na borda
                if (peixe.x < 0) peixe.x = 0;
                if (peixe.x > width) peixe.x = width;
            }
        }
    }
}

function updateTiroJogo() { // Nova função de atualização para o Tiro
    if (jogoTiroAtivo) {
        // Atualiza o tempo restante
        tempoRestanteTiro = duracaoJogoTiro - (millis() - tempoInicioJogoTiro) / 1000;

        // Animação de tranco da arma
        if (trancoAnimando) {
            trancoTimer++;
            if (trancoTimer < 5) { // Tranco para cima/trás
                trancoOffset = -map(trancoTimer, 0, 5, 0, 10);
            } else if (trancoTimer < 10) { // Retorno à posição normal
                trancoOffset = -map(trancoTimer, 5, 10, 10, 0);
            } else {
                trancoAnimando = false;
                trancoOffset = 0;
                trancoTimer = 0;
            }
        }

        // Se o tempo acabou, muda para a tela de fim de jogo
        if (tempoRestanteTiro <= 0) {
            tempoRestanteTiro = 0; // Garante que não mostre tempo negativo
            jogoTiroAtivo = false; // Garante que o jogo não continua atualizando
            determinarPremioFinal(); // Determina o prêmio antes de mudar de estado
            gameState = 'tiro_fim_jogo';
            return; // Sai da função para evitar processamento desnecessário
        }

        // Gera novos alvos
        if (frameCount >= tempoParaNovoAlvo && alvos.length < maxAlvosAtivos) {
            alvos.push(criarAlvo());
            tempoParaNovoAlvo = frameCount + intervaloGeracaoAlvo; // Próximo alvo
        }

        // Atualiza e remove alvos
        for (let i = alvos.length - 1; i >= 0; i--) {
            let alvo = alvos[i];
            if (alvo.ativo) {
                // Move os alvos (agora eles se movem na vertical)
                alvo.y += alvo.velocidadeY;
                // Inverte a direção se atingir as bordas superior ou inferior
                // Os alvos aparecerão na tela inteira na vertical, então os limites são height/2 - altura do alvo e height - 70 (chão) - altura do alvo
                let minY = alvo.size / 2; // Parte superior da tela
                let maxY = height - 70 - alvo.size / 2; // Acima do chão

                if (alvo.y < minY || alvo.y > maxY) {
                    alvo.velocidadeY *= -1; // Inverte a direção vertical
                }

                // Faz o alvo sumir se o tempo visível acabar
                if (frameCount > alvo.tempoCriacao + tempoAlvoVisivel) {
                    alvo.ativo = false; // Desativa o alvo se o tempo dele acabou
                }
            } else {
                // Remove alvos inativos (atingidos ou que sumiram)
                alvos.splice(i, 1);
            }
        }
    }
}

// =========================================================
// Funções de Eventos (Teclado/Mouse)
// =========================================================

function keyPressed() {
    if (gameState === 'cidade') {
        if (key === ' ' && showNpcDialog) {
            npcDialogStep++;
            if (npcDialogStep >= npcDialogs.length) {
                gameState = 'caminho_festa';
                // Resetar npcX para que ele apareça novamente na próxima vez que a cidade for carregada
                npcX = width + 50;
                showNpcDialog = false; // Esconde o diálogo após a transição
                npcDialogStep = 0; // Reseta o passo do diálogo
            }
        }
    } else if (gameState === 'pescaria_dialogo') {
        if (key === 's' || key === 'S') {
            gameState = 'pescaria_jogo';
            // Desativa o chapéu ao entrar na pescaria (para não atrapalhar a visão do anzol)
            playerHasHat = false;
            // Reseta a pontuação e itens ao iniciar um novo jogo de pescaria
            pontuacaoPescaria = 0;
            ultimoItemGanhoPescaria = -1;
            mensagemItemAtualPescaria = "";
            // Reinicia os peixes para um novo começo
            peixes = [];
            for (let i = 0; i < 5; i++) {
                peixes.push(criarPeixe());
            }
        } else if (key === 'n' || key === 'N') {
            gameState = 'festa_junina';
            // Reativa o chapéu ao voltar para a festa
            playerHasHat = true;
        }
    } else if (gameState === 'tiro_dialogo') { // Novo evento de teclado para o diálogo do tiro
        if (key === 's' || key === 'S') {
            gameState = 'tiro_jogo';
            // Desativa o chapéu ao entrar no tiro
            playerHasHat = false;
            pontuacaoTiro = 0;
            alvos = []; // Limpa alvos anteriores
            tempoInicioJogoTiro = millis(); // Guarda o tempo de início do jogo
            jogoTiroAtivo = true; // Ativa o jogo de tiro
            tempoParaNovoAlvo = frameCount; // Garante que o primeiro alvo apareça logo
        } else if (key === 'n' || key === 'N') {
            gameState = 'festa_junina';
            // Reativa o chapéu ao voltar para a festa
            playerHasHat = true;
        }
    } else if (gameState === 'tiro_fim_jogo') { // Se estiver na tela de fim de jogo de tiro
        if (key === ' ' || key === 'SPACE') { // Pressionar espaço para voltar à festa
            // Ativa o chapéu ao retornar para a festa
            playerHasHat = true;

            gameState = 'festa_junina';
            // Retorna o jogador para o centro da festa
            playerX = width / 2;
            playerY = height - 50;
        }
    }
}

function mousePressed() {
    // Se o jogo está na tela de início, um clique inicia a música e o jogo
    if (gameState === 'inicio') {
        // Verifica se o clique foi dentro do botão de início
        if (mouseX > startButtonX && mouseX < startButtonX + startButtonWidth &&
            mouseY > startButtonY && mouseY < startButtonY + startButtonHeight) {
            // Toca a música do caminho em loop
            if (!musicaCaminho.isPlaying()) {
                musicaCaminho.loop();
            }
            gameState = 'cidade'; // Muda para a cena da cidade
            return; // Sai da função para não executar outras lógicas de clique
        }
    }

    // Lógica para iniciar a música (caso o usuário interaja em outro estado)
    // Isso é uma garantia, mas com a tela de início, é menos provável que seja necessário
    if (gameState === 'caminho_festa' && !musicaCaminho.isPlaying()) {
        musicaCaminho.loop();
    } else if ((gameState === 'festa_junina' || gameState === 'pescaria_jogo' || gameState === 'pescaria_dialogo' || gameState === 'tiro_jogo' || gameState === 'tiro_dialogo' || gameState === 'tiro_fim_jogo') && !musicaFesta.isPlaying()) {
        musicaFesta.loop();
    }

    // Lógica do jogo de pescaria
    if (gameState === 'pescaria_jogo') {
        // Verifica se clicou no botão SAIR
        if (mouseX > exitButtonX && mouseX < exitButtonX + exitButtonWidth &&
            mouseY > exitButtonY && mouseY < exitButtonY + exitButtonHeight) {
            gameState = 'festa_junina'; // Volta para a festa junina
            // MUDANÇA: Reiniciar a posição do pescador para o centro da festa
            playerX = width / 2;
            playerY = height - 50;
            // Reativa o chapéu ao voltar para a festa
            playerHasHat = true;
            return; // Sai da função para não lançar o anzol ou fazer outra coisa
        }

        // Se não clicou no botão SAIR, então lança o anzol
        // O anzol só pode ser lançado se estiver na posição inicial e não houver um peixe pego
        if (anzolY === pescadorY - 10 && !isLancando) { // Apenas se o anzol estiver na vara e não estiver lançando
            isLancando = true;
            peixePego = null; // Reinicia o peixe pego para a nova tentativa
        }
    }

    // Lógica do jogo de tiro ao alvo
    if (gameState === 'tiro_jogo' && jogoTiroAtivo) { // Só permite atirar se o jogo estiver ativo
        // Verifica se clicou no botão SAIR
        if (mouseX > exitButtonX && mouseX < exitButtonX + exitButtonWidth &&
            mouseY > exitButtonY && mouseY < exitButtonY + exitButtonHeight) {
            gameState = 'festa_junina'; // Volta para a festa junina
            // MUDANÇA: Volta o player para o centro da festa
            playerX = width / 2;
            playerY = height - 50;
            jogoTiroAtivo = false; // Para o jogo de tiro
            alvos = []; // Limpa os alvos
            // Reativa o chapéu ao voltar para a festa
            playerHasHat = true;
            return;
        }

        // Se não clicou no botão SAIR, tenta acertar um alvo
        trancoAnimando = true; // Inicia a animação de tranco
        trancoTimer = 0; // Reinicia o timer do tranco

        for (let alvo of alvos) {
            if (alvo.ativo) {
                // A colisão agora é com a mira (mouseX, mouseY)
                let d = dist(mouseX, mouseY, alvo.x, alvo.y);
                // Pontuação baseada na distância do centro
                let pontosAcerto = 0;
                if (d < alvo.size * 0.2) { // Acertou o centro (vermelho) - 20% do tamanho
                    pontosAcerto = 5; // Aumentado para 5, antes era 10
                } else if (d < alvo.size * 0.35) { // Acertou o preto - 35% do tamanho
                    pontosAcerto = 3; // Aumentado para 3, antes era 5
                } else if (d < alvo.size * 0.5) { // Acertou o branco - 50% do tamanho
                    pontosAcerto = 1; // Aumentado para 1, antes era 2
                }

                if (pontosAcerto > 0) { // Se acertou alguma parte do alvo
                    alvo.ativo = false; // Desativa o alvo
                    pontuacaoTiro += pontosAcerto;
                    break; // Acertou um alvo, sai do loop
                }
            }
        }
    }
}


// =========================================================
// Funções Auxiliares (Desenho de elementos genéricos)
// =========================================================

// Desenha o stickman
// O parâmetro 'withHat' foi mantido para a fogueira central da festa.
function drawStickman(x, y, rotation, withHat = false) {
    push();
    translate(x, y);
    rotate(rotation);
    stroke(0);
    strokeWeight(2);

    // Corpo
    line(0, -20, 0, 0);

    // Cabeça
    fill(255);
    ellipse(0, -35, 30, 30);

    // Braços
    line(-15, -10, 15, -10);

    // Pernas
    line(0, 0, -10, 20);
    line(0, 0, 10, 20);

    // Desenha o chapéu se 'withHat' for true e a imagem estiver carregada
    if (withHat && chapeuImg) {
        imageMode(CENTER);
        // Ajuste FIXO do tamanho do chapéu: Largura 38 pixels, Altura 28 pixels.
        // A posição Y foi ajustada para -50 para o chapéu ficar um pouco mais alto na cabeça.
        image(chapeuImg, 0, -50, 38, 28);
        imageMode(CORNER);
    }
    pop();
}

// Desenha uma caixa de diálogo
function drawDialogBox(textMessage) {
    fill(255, 255, 200); // Fundo da caixa
    stroke(0); // Contorno da caixa
    strokeWeight(1); // Espessura do contorno da caixa
    rect(width / 2 - 200, height - 150, 400, 100, 10); // Caixa

    fill(0); // Cor do texto
    noStroke(); // Garante que o texto NÃO terá contorno
    textSize(18);
    textAlign(CENTER, CENTER);
    text(textMessage, width / 2, height - 120);
    // Mensagem para pressionar espaço
    if (npcDialogStep < npcDialogs.length - 1) {
        textSize(14);
        text("Pressione ESPAÇO para continuar...", width / 2, height - 80);
    }
    textAlign(LEFT, BASELINE); // Resetar alinhamento
}

// Função para criar um novo peixe
function criarPeixe() { // Retornou à versão anterior mais simples
    let tamanhoAleatorio = random(20, 40);
    let pontos = 1;

    if (tamanhoAleatorio > 35) {
        pontos = 3;
    } else if (tamanhoAleatorio > 28) {
        pontos = 2;
    } else {
        pontos = 1;
    }

    // Peixes sempre começam na direita e vão para a esquerda
    let startX = width + 20;
    let velocidadeX = random(-2, -0.5); // Velocidade negativa para ir para a esquerda

    return {
        x: startX,
        y: random(barcoY + 80, height - 30), // Y dos peixes ajustado para dentro da água
        tamanho: tamanhoAleatorio,
        velocidadeX: velocidadeX,
        cor: { r: random(255), g: random(255), b: random(255) },
        pego: false,
        pontos: pontos
    };
}


// Nova função para criar um alvo
function criarAlvo() {
    let alvoSize = random(30, 50);
    let startY = random(alvoSize / 2, height - 70 - alvoSize / 2); // Alvos aparecerão em qualquer Y na tela

    let startX;
    let velocidadeY;

    // Alvo pode vir do canto esquerdo ou direito
    if (random() > 0.5) { // Vem do canto esquerdo
        startX = width * 0.1; // Canto esquerdo, 10% da largura
        velocidadeY = random([-1, 1]) * random(0.5, 1.5); // Movimento vertical aleatório
    } else { // Vem do canto direito
        startX = width * 0.9; // Canto direito, 90% da largura
        velocidadeY = random([-1, 1]) * random(0.5, 1.5); // Movimento vertical aleatório
    }

    return {
        x: startX, // Posicionado nos cantos
        y: startY,
        size: alvoSize,
        ativo: true,
        velocidadeY: velocidadeY, // Agora os alvos se movem na vertical
        tempoCriacao: frameCount // Guarda o frame em que o alvo foi criado
    };
}


// Função para desenhar uma nuvem
function drawCloud(x, y, size) {
    // A cor e o contorno já são definidos ANTES de chamar esta função
    // (e.g., fill(255); noStroke(); em drawCidade() ou drawPescariaJogo())
    ellipse(x, y, 50 * size, 50 * size);
    ellipse(x + 25 * size, y, 40 * size, 40 * size);
    ellipse(x - 25 * size, y, 40 * size, 40 * size);
    ellipse(x + 12 * size, y - 15 * size, 30 * size, 30 * size);
    ellipse(x - 12 * size, y - 15 * size, 30 * size, 30 * size);
}

// Função para desenhar bandeirinhas
function drawBandeirinhas(startY, offsetHeight) {
    let colors = [color(255, 0, 0), color(0, 255, 0), color(0, 0, 255), color(255, 255, 0)];
    let flagWidth = 20;
    let flagSpacing = 15;
    let totalFlags = ceil(width / (flagWidth + flagSpacing)) + 2;

    for (let i = 0; i < totalFlags; i++) {
        let x = i * (flagWidth + flagSpacing);
        let y = startY + sin(i * 0.5 + frameCount * 0.05) * offsetHeight;

        fill(colors[i % colors.length]);
        noStroke(); // Garante que a bandeirinha não tenha contorno
        triangle(x, y, x + flagWidth, y, x + flagWidth / 2, y + flagWidth);
        stroke(0); // Volta o contorno para a linha
        strokeWeight(2);
        line(x, y, x + flagWidth, y);
    }
    noStroke(); // Limpa o contorno no final
}


// Nova função para desenhar uma barraca típica de festa junina
function drawFestaJuninaBarraca(x, y, roofColor, textDisplay = null) {
    push();
    translate(x, y);

    // Corpo principal da barraca
    fill(139, 69, 19);
    noStroke(); // Sem contorno para o corpo da barraca
    rect(0, -70, 100, 70);

    // Balcão
    fill(160, 82, 45);
    noStroke(); // Sem contorno para o balcão
    rect(0, -70, 100, 10);

    // Postes
    stroke(0);
    strokeWeight(2);
    line(5, -70, 5, -150);
    line(95, -70, 95, -150);

    // Teto da barraca
    noStroke();
    fill(roofColor);
    triangle(-10, -150, 110, -150, 50, -200);

    // Listras no teto
    fill(255);
    triangle(-10, -150, 20, -150, 50, -200);
    triangle(20, -150, 50, -150, 50, -200);
    triangle(50, -150, 80, -150, 50, -200);
    triangle(80, -150, 110, -150, 50, -200);

    // Desenha o texto na barraca
    if (textDisplay) {
        fill(0);
        noStroke(); // Garante que o texto NÃO terá contorno
        textSize(20);
        textAlign(CENTER, CENTER);
        text(textDisplay, 50, -60);
        textAlign(LEFT, BASELINE);
    }

    pop();
}

// Nova função para desenhar estrelas
function drawStars() {
    fill(255, 255, 200, 200);
    noStroke();
    for (let i = 0; i < stars.length; i++) {
        let star = stars[i];
        ellipse(star.x, star.y, star.size, star.size);
    }
}

// Nova função para desenhar um carro
function drawCar(x, y) {
    push();
    translate(x, y);

    // Corpo do carro
    fill(255, 0, 0);
    noStroke(); // Sem contorno para o corpo do carro
    rect(0, 0, 120, 40);
    rect(20, -30, 80, 30);

    // Rodas
    fill(50);
    noStroke(); // Sem contorno para as rodas
    ellipse(30, 40, 30, 30);
    ellipse(90, 40, 30, 30);

    // Janelas
    fill(170, 200, 255);
    noStroke(); // Sem contorno para as janelas
    rect(25, -25, 30, 20);
    rect(65, -25, 30, 20);

    pop();
}

// Nova função para desenhar placa de sinalização
function drawRoadSign(x, y, textMessage, direction) {
    push();
    translate(x, y);

    // Poste da placa
    fill(100, 70, 40);
    noStroke(); // Sem contorno para o poste
    rect(0, 0, 10, 80);

    // Corpo da placa
    fill(200, 200, 0); // Amarelo
    noStroke(); // Sem contorno para o corpo da placa
    rect(-50, -50, 150, 40, 5); // Placa retangular

    // Texto
    fill(0);
    noStroke(); // Garante que o texto NÃO terá contorno
    textSize(18);
    textAlign(CENTER, CENTER);
    text(textMessage, 25, -30);

    // Seta de direção
    stroke(0); // Contorno para a seta
    strokeWeight(1);
    if (direction === "direita") {
        triangle(90, -30, 105, -30 + 10, 105, -30 - 10); // Ponta da seta
        rect(80, -32, 10, 5); // Corpo da seta
    } else if (direction === "esquerda") {
        triangle(-40, -30, -55, -30 + 10, -55, -30 - 10);
        rect(-30, -32, 10, 5);
    }

    textAlign(LEFT, BASELINE);
    pop();
}

// =========================================================
// NOVAS FUNÇÕES PARA ARMA, MIRA E PRÊMIOS
// =========================================================

// Função para desenhar a espingarda, agora com a base fixa
function drawArma(armaBaseX, armaBaseY, miraX, miraY) {
    push(); // Salva o estado atual de desenho
    translate(armaBaseX, armaBaseY); // Move para a base da arma

    // Calcula o ângulo da ponta da arma em relação à mira
    // A origem do ângulo é a base da arma, mas queremos que o cano aponte para a mira
    // O cano é desenhado *acima* da base.
    let canoTipX = 0; // Posição X da ponta do cano em relação à base
    let canoTipY = -150; // Posição Y da ponta do cano em relação à base (ajustado para o desenho do cano)

    // Calcula o vetor da mira em relação à base da arma
    let vecX = miraX - armaBaseX;
    let vecY = miraY - (armaBaseY + trancoOffset); // Considerando o tranco na mira Y

    // Ajusta o ângulo para que o cano aponte para a mira
    // Usamos o ângulo entre o vetor da mira e o vetor do cano quando a arma está reta (0, -150)
    let angle = atan2(vecY, vecX) + PI / 2; // +PI/2 para corrigir a orientação vertical original

    rotate(angle); // Rotaciona a arma

    // Corpo da espingarda
    fill(100, 70, 40); // Marrom escuro
    noStroke();
    rect(-10, -60, 20, 80, 5); // Coronha

    // Gatilho
    fill(50);
    rect(-2, 10, 4, 10); // Gatilho
    arc(0, 10, 15, 15, 0, PI); // Guarda-mato

    // Corpo principal da espingarda (parte de metal)
    fill(80, 80, 80); // Cinza escuro
    rect(-8, -100, 16, 40, 3); // Parte de trás do corpo
    rect(-6, -150, 12, 50, 3); // Cano

    // Detalhes no cano
    fill(60, 60, 60);
    rect(-4, -140, 8, 5);

    pop(); // Restaura o estado anterior de desenho
}


function drawMira(x, y) {
    push(); // Salva o estado de desenho
    translate(x, y); // Move para a posição do mouse

    // Cor da mira
    stroke(miraCor[0], miraCor[1], miraCor[2]); // Vermelho
    strokeWeight(2); // Espessura da linha da mira

    // Linhas horizontais e verticais
    line(-miraSize / 2, 0, miraSize / 2, 0); // Linha horizontal
    line(0, -miraSize / 2, 0, miraSize / 2); // Linha vertical

    // Círculo central (opcional, para um ponto mais claro)
    noFill(); // Sem preenchimento para o círculo
    ellipse(0, 0, miraSize * 0.6, miraSize * 0.6);

    pop(); // Restaura o estado de desenho
}


function determinarPremioFinal() {
    if (pontuacaoTiro >= 50) { // Pontuação alta
        premioFinalTiro = "Um Urso de Pelúcia Gigante!";
    } else if (pontuacaoTiro >= 30) {
        premioFinalTiro = "Um Urso de Pelúcia Médio!";
    } else if (pontuacaoTiro >= 15) {
        premioFinalTiro = "Uma Bola de Futebol!";
    } else if (pontuacaoTiro >= 5) {
        premioFinalTiro = "Um Chaveiro Exclusivo!";
    } else {
        premioFinalTiro = "Um 'Até a Próxima!' (Tente de novo!)"; // Consolo para pontuação baixa
    }
}